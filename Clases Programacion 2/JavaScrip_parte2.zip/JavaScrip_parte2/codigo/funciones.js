/* -----Funciones------ */

/* Funciones nativas*/

let a =10;
let b = '1' +3 +'10';


console.log (parseFloat(a)+parseFloat(b));



/* Funciones Propias */

function mifuncion(){
  //Intrucciones Funciones;
}
/* Evento onClick */




/* ---------Flecha -------------- */

// Función tradicional
let suma = function(a, b) {
  return a + b;
};

/* Flecha */
let sum = (a, b) => a + b;

